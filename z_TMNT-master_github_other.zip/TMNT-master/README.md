# TMNT
A website for Rotten Tomatoes that provides the characteristics for the 2007 movie "Teenage Mutant Ninja Turtles"
In order to see the website, do the following:
- download WAMP (for Windows machines), LAMP (for Linux machines), MAMP (for Macintosh machines)
- save all the files from here (my github repository TMNT) in one folder and name it anything you want
  (for example, "TMNT")
- put that "TMNT" folder in the "htdocs" or "www" directory when you open your WAMP, LAMP, MAMP folder
- run WAMP/LAMP/MAMP (if the icon is green everything works fine)
- open a web browser and type "localhost:8888/TMNT" and select the tmnt.html file to see the website
- 8888 is the port number but for your machine it might be different - it could be 80 or 8080
- Enjoy!
